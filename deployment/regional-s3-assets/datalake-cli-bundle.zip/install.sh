#!/bin/bash
cd ./datalake-cli-bundle
npm link
